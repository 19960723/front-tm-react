import{j as r}from"./index-C7UBUP4N.js";const e=()=>r.jsx(r.Fragment,{children:"forum"});export{e as default};
