import{j as e}from"./index-C7UBUP4N.js";const s=()=>e.jsx(e.Fragment,{children:"movies"});export{s as default};
