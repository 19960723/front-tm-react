import{j as t}from"./index-C7UBUP4N.js";const r=()=>t.jsx(t.Fragment,{children:"planet"});export{r as default};
